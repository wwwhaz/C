#include <stdio.h>

int main(){
	int i;

	for(i=3;i<=100;i++)

		fib[i]=fib[i-1]+fib[i-2];
