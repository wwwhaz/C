#include<stdio.h>
#include <stdlib.h>
long num(int n)
{
	int i;
	 r[10000];
	if ( n == 1 || n == 2)
		 return 1;
	for (i=3; i<=10000; i++)



	{
			r[i]= (r[i-1]+r[i-2]);

	}
	

	return r[i];

}

int main()
{
	int month, k;
	printf("Please input the number of generations (>0)�G\n");
	scanf("%d", &month);

	for (k = 1; k <= month; k++)
	{
		printf("��0%d�N�ƶq:%1d\n",k,num(k));
	}
	
}
	

